Valid inputs that will shoe the structural breakdown:

1) I like the evening breeze
2) She like the dog
3) you fly against them
4) I apologize your evening guard
5) Both achieve a accounting allowance


Invalid Word Type: Any word that is not present in the list of words we've provided from the standard source (Google)
Example:
I don't lo the dog. (lo is not recognized thus it's invalid word type)

Invalid Structure: Any sentence that doesn't follow the structure that we have mentioned before in the image
Example:

I evening breeze the morning. (Normal structure of sentence is Noun Phrase followed by a Verb Phrase which doesn't satisfies in this case so it gives the output invalid structure.)