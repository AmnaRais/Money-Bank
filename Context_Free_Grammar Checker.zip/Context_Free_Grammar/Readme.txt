Group Members:
23K-0585 MARYIAM KHAN
23K-0876 AIMAN NADEEM
23K-0824 AMNA RAIS
*************************

1) Start your execution from main.cpp. sign-in first, then log-in.
2) Then enter text/ sentence to check for structure.